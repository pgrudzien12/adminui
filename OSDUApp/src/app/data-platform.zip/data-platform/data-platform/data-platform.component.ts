import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonService } from 'src/app/common/common.service';
import { RestAPILayerService } from 'src/app/common/rest-apilayer.service';
import { AuthService} from 'src/app/common/Authentication/auth.service';
import { NgbModal,ModalDismissReasons, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { element } from 'protractor';
import { KeyValue } from '@angular/common';
import { DataPlatformList } from 'src/config';

@Component({
  selector: 'app-data-platform',
  templateUrl: './data-platform.component.html',
  styleUrls: ['./data-platform.component.css']
})
export class DataPlatformComponent implements OnInit {

  originalOrder = (a: KeyValue<number,string>, b: KeyValue<number,string>): number => {
    return 0;
  }


  isWellSearchAvailable:boolean=false;
  errorMessage:string='';
  pageSize = 6;  
  page=1
  storageKindList=[];
  selectedStorageKind:any;
  searchList=[];
  schemaList=[];
  ngQuery='';
  isAuthorized:boolean=false;
  isSearchSelected:boolean=false;
  items = [
    {id: 1, name: 'Python'},
    {id: 2, name: 'Node Js'},
    {id: 3, name: 'Java'},
    {id: 4, name: 'PHP', disabled: true},
    {id: 5, name: 'Django'},
    {id: 6, name: 'Angular'},
    {id: 7, name: 'Vue'},
    {id: 8, name: 'ReactJs'},
  ];


  newarr=[{"Data.abc": "srn:master-data/GeopoliticalEntity:Netherlands:",
  "DataSourceOrganisationID": "srn:master-data/Organisation:TNO:",
  "DefaultVerticalMeasurementID": "Maaiveld"},
  {
    "Data": "srn:master-data/GeopoliticalEntity:Netherlands:",
  "DataSourceOrganisationID": "srn:master-data/Organisation:TNO:",
  "DefaultVerticalMeasurementID": "Rotary Table"
  },
  {
    "Data": "Netherlands:",
  "DataSourceOrganisationID": "isation:TNO:",
  "DefaultVerticalMeasurementID": "Rotary"
  }]
  headers=Object.keys(this.newarr[0])

 // headersList=["DataSourceOrganisationID","FacilityName","TrajectoryTypeID","FacilityTypeID","SequenceNumber","PrimaryMaterialID",
//"ResourceID","DefaultVerticalMeasurementID","FieldID","ResourceTypeID","ResourceSecurityClassification","HorizontalCRSID","WellID"]
headersList=[];
  constructor(private auth:AuthService, public cmnSrvc: CommonService, private restService: RestAPILayerService,private spinner: NgxSpinnerService,) {
    this.cmnSrvc.sideNavLists=DataPlatformList[0]["sideValues"];
    this.cmnSrvc.SideNavHeader=DataPlatformList[0]["header"]; 
   }

  ngOnInit(): void {
    this.getStorageKind();
  }

  getStorageKind(){    
    this.spinner.show();
    let timer = this.auth.refreshTokenTimer(this.auth.getIdToken());
    if(timer<=0){
      this.auth.subscribeRefreshToken();     
    }
    this.restService.getStorageKindList().subscribe((result) => {
      this.spinner.hide();
      this.isAuthorized=true;
     if(typeof(result) !="string"){
       this.storageKindList=result["results"];
     }

    }, (err) => {
      this.isAuthorized=false;
      this.errorMessage=err;
     this.spinner.hide();
      console.log(err);
    });
    
  }
    
  getSearchWells(){
    let query="data.Data.IndividualTypeProperties.WellID:\"srn:master-data/Well:8690:\"";
    this.headersList=[];
    var tempHeaderList=[];
    if(this.ngQuery!=''){
      query=this.ngQuery;
    }

    this.spinner.show();
    let timer = this.auth.refreshTokenTimer(this.auth.getIdToken());
    if(timer<=0){
      this.auth.subscribeRefreshToken();     
    }

    this.restService.SearchWells(query.toString(),this.selectedStorageKind).subscribe((result) => {     
      this.spinner.hide();
      console.log(result);
      let searchList=result["results"].map(x=>x.data);
      let that=this; 
      tempHeaderList=[];
      let tempSearchArr=[];
      searchList.forEach(element => {
        let headrVals=Object.keys(element);
        headrVals.forEach(ele => {
          if(!(tempHeaderList.includes(ele))){
            tempHeaderList.push(ele);
          }          
        });    
          
      });
      
      searchList.forEach(element => {
        let temparr = {};

        for (var j = 0; j < tempHeaderList.length; j++) {
          if (tempHeaderList.includes(Object.keys(element)[j])) {
          // if (tempHeaderList[j] == Object.keys(element)[j]) {
            let obkey = Object.keys(element)[j];
            temparr[obkey] = element[tempHeaderList[j]]
            //console.log(temparr)
          }
          else {
            temparr[tempHeaderList[j]] = 'NA'
          }

        }
        tempSearchArr.push(temparr);

      });
      this.headersList=[];
      this.isSearchSelected=true;
      let tempHead=Object.keys(tempSearchArr[0]);
      tempHead.forEach(element => {
        this.headersList.push(element.replace(/([@.])/g,"$1<wbr>")); 
      });
      this.headersList.sort();
      that.searchList = tempSearchArr;     

   
    }, (err) => {
     this.spinner.hide();
     this.errorMessage=err;
     this.searchList=[];
      console.log(err);
    });
    
  }

  requestSubmit(){
    this.isWellSearchAvailable=true;
    

    this.getSearchWells();
  }
}
