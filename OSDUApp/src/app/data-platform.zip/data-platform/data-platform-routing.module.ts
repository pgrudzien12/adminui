import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AuthGuard } from '../auth.guard';
import { DataPlatformComponent} from './data-platform/data-platform.component';



const routes: Routes = [
    // { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: '',  component: DataPlatformComponent,canActivateChild:[AuthGuard], children:[
           
    ] },
  
  
  ];
  
  @NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })
  export class DataPlatformRoutingModule { } 