import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataPlatformComponent } from './data-platform/data-platform.component';
import { DataPlatformRoutingModule} from './data-platform-routing.module';
import { NgxSpinnerModule,NgxSpinnerService} from 'ngx-spinner';
import { FormsModule } from '@angular/forms';
import { NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { NgSelectModule } from '@ng-select/ng-select';

@NgModule({
  declarations: [DataPlatformComponent],
  imports: [
    CommonModule,DataPlatformRoutingModule,NgxSpinnerModule,FormsModule,NgbModule,NgSelectModule
  ]
})
export class DataPlatformModule { }
