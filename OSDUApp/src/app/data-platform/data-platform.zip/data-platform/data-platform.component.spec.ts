import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataPlatformComponent } from './data-platform.component';

describe('DataPlatformComponent', () => {
  let component: DataPlatformComponent;
  let fixture: ComponentFixture<DataPlatformComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataPlatformComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataPlatformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
