import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonService } from 'src/app/common/common.service';
import { RestAPILayerService } from 'src/app/common/rest-apilayer.service';
import { AuthService} from 'src/app/common/Authentication/auth.service';
import { NgbModal,ModalDismissReasons, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { element } from 'protractor';
import { KeyValue } from '@angular/common';
import { DataPlatformList } from 'src/config';
import { Router } from '@angular/router';
import { timeStamp } from 'console';
import { search_dpd_helptxt,search_modifyFilter,search_spatailfilter} from 'src/config';

@Component({
  selector: 'app-data-platform',
  templateUrl: './data-platform.component.html',
  styleUrls: ['./data-platform.component.css']
})
export class DataPlatformComponent implements OnInit {

  originalOrder = (a: KeyValue<number,string>, b: KeyValue<number,string>): number => {
    return 0;
  }


  isWellSearchAvailable:boolean=false;
  errorMessage:string='';
  pageSize = 10;
  page=1
  storageKindList=[];
  selectedStorageKind:any;
  searchList=[];
  schemaList=[];
  ngQuery='';
  isAuthorized:boolean=false;
  isSearchSelected:boolean=false;
  isShowSearch:boolean=false;
  isShowSpatialFilter:boolean=false;
  isSpatialAvailable:boolean=false;
  isSpatialLoc:boolean=false;
  selectedWellDetails:any;
  fullSearchResult=[]
  isDisabled:boolean=false;
  ngCheckUserOwned;
  isUserOwned:boolean=false;
  search_btn_dpd_help=search_dpd_helptxt;
  search_modifyFilter=search_modifyFilter;
  search_spatailfilter=search_spatailfilter;
  //search_legal_navigate=search_legal_navigate;
  spatialArr=[];
  searchObjectArr=[];
 // headersList=["DataSourceOrganisationID","FacilityName","TrajectoryTypeID","FacilityTypeID","SequenceNumber","PrimaryMaterialID",
//"ResourceID","DefaultVerticalMeasurementID","FieldID","ResourceTypeID","ResourceSecurityClassification","HorizontalCRSID","WellID"]
headersList=[];
  constructor(private auth:AuthService,private router:Router, public cmnSrvc: CommonService, private restService: RestAPILayerService,private spinner: NgxSpinnerService,) {
    this.cmnSrvc.isUserGuide=true;
    this.cmnSrvc.bkgndColor="dataPlatform";
    this.cmnSrvc.userGuideLink="https://community.opengroup.org/osdu/ui/admin-ui/-/wikis/Admin-UI-User-Guide-Search-for-Data.";
   }

  ngOnInit(): void {
    this.cmnSrvc.isUserGuide=true;
    this.cmnSrvc.bkgndColor="dataPlatform";
    this.cmnSrvc.userGuideLink="https://community.opengroup.org/osdu/ui/admin-ui/-/wikis/Admin-UI-User-Guide-Search-for-Data.";
    this.getStorageKind();
    
  }

  getStorageKind(){    
    this.spinner.show();
    let timer = this.auth.refreshTokenTimer(this.auth.getIdToken());
    if(timer<=0){
      this.auth.subscribeRefreshToken();     
    }
    const data={
      "kind": "*:*:*:*"
    }
    this.restService.getStorageKindList(data).subscribe((result) => {
      this.spinner.hide();
      this.isAuthorized=true;
     if(typeof(result) !="string"){
       this.storageKindList=result["results"];
     }

    }, (err) => {
      this.spinner.hide();
      this.isAuthorized=false;
      if(err.error != undefined){
        this.errorMessage=err.error;
        
      }
      else{
        this.errorMessage=err;
      }
  
    
      console.log(err);
    });
    
  }
    
  requestSubmit(){
    this.isWellSearchAvailable=true;   

    let query="data.Data.IndividualTypeProperties.WellID:\"srn:master-data/Well:8690:\"";
   
    if(this.ngQuery!=''){
      query=this.ngQuery;
    }

    this.spinner.show();
    let timer = this.auth.refreshTokenTimer(this.auth.getIdToken());
    if(timer<=0){
      this.auth.subscribeRefreshToken();     
    }
    const data={
      "kind":this.selectedStorageKind
    }       
    this.getSearchDetails(data,'full');
  }





  getSearchDetails(data,type){
    this.spinner.show();
    if(type=='filter'){
      data=JSON.parse(data);
    }
   if(this.isUserOwned){
     data["queryAsOwner"]=this.isUserOwned;   
   }
   let id=this.selectedStorageKind
    this.restService.SearchWells(id).subscribe((result) => {     
      this.spinner.hide();  
      this.searchResultFunction(result,type);    
   
    }, (err) => {
     this.spinner.hide();
     this.errorMessage=err;
     this.searchList=[];
     this.isDisabled=false;
      console.log(err);
    }); 
  }

  searchResultFunction(result,type){
    this.headersList=[];
    var tempHeaderList=[];
    this.isSearchSelected=true;
    let completeResult=[];
    if(type=='user'){
      completeResult=result;
    }
   else{
    completeResult= result;
   }
   
   // if(completeResult.length>0){
      this.isDisabled=true;
      console.log(result);
      // let searchList=completeResult.map(x=>x.data);
      let searchList=completeResult["data"]
      let that=this; 
      tempHeaderList=[];
      let tempSearchArr=[]; 
      let tempPassArr=[];
     
      if(!(tempHeaderList.includes("id"))){
            tempHeaderList.push(".Id");
            
      }  
      completeResult.forEach(element => {
        if(!(tempHeaderList.includes("..Legal Tag"))){
          tempHeaderList.push("..Legal Tag");
        
        } 
             
        let search_data=element["data"];
        if(search_data !=undefined){
          let headrVals=Object.keys(search_data);
          headrVals.forEach(ele => {
            if(!(tempHeaderList.includes(ele))){
              tempHeaderList.push(ele);
             
            }          
          }); 
        }
     
        
      });
     
      completeResult.forEach(element => {
        let temparr = {};
        let tempPassObject={};
        let TempWithoutLegal=[];
        temparr[tempHeaderList[0]] = element["id"]; 
        temparr[tempHeaderList[1]] = element["legal"]["legaltags"]; 
        tempPassObject[tempHeaderList[0]] = element["id"]; 
        tempPassObject[tempHeaderList[1]] = element["legal"]["legaltags"]; 
        TempWithoutLegal=tempHeaderList.filter(x=>x !="..Legal Tag");
        TempWithoutLegal=TempWithoutLegal.filter(x=>x != ".Id");
        let obkey;
        if(element["data"] !=undefined){
           obkey = Object.keys(element["data"]);
        }
        
        for (var j = 0; j < TempWithoutLegal.length; j++) {
          if(element["data"] !=undefined){
            if (TempWithoutLegal.includes(Object.keys(element["data"])[j])) {         
              let obkey = Object.keys(element["data"])[j];
              let res_data= element["data"][obkey];
              tempPassObject[obkey]=res_data;
              if(typeof(element["data"][obkey])=="object"){
                this.isSpatialAvailable=true;
                // if(obkey=="SpatialLocation"){
                //   this.isSpatialLoc=true;
                //   if(!this.spatialArr.includes(obkey)){
                //     this.spatialArr.push(obkey);
                //   }
                 
                // }
                if(!(this.searchObjectArr.includes(obkey))){
                  this.searchObjectArr.push(obkey);
                }
                
                temparr[obkey] = JSON.stringify(res_data);
                
              }
              else{             
                temparr[obkey] = res_data;
              }
            
            }
            else {
              temparr[TempWithoutLegal[j]] = 'NA';
              tempPassObject[TempWithoutLegal[j]] = 'NA'
            }
          }
          else{
            temparr[TempWithoutLegal[j]] = 'NA';
            tempPassObject[TempWithoutLegal[j]] = 'NA'
          }
        
        }
       
        tempSearchArr.push(temparr);
        tempPassArr.push(tempPassObject);

      });
      this.selectedWellDetails=tempSearchArr;
      if(type=='full'){
        this.fullSearchResult=tempPassArr;
      }
     
      this.headersList=[];
      
      let tempHead=Object.keys(tempSearchArr[0]);
      tempHead.forEach(element => {
        this.headersList.push(element.replace(/([@.])/g,"$1<wbr>")); 
      });
      this.headersList.sort();
      that.searchList = tempSearchArr;     
      this.errorMessage='';
    // }
    // else{
    //   this.isDisabled=false;
    //   this.searchList=[];
    // }
  }
 
  openModalLegalTags(legal){
    console.log(legal);
    this.router.navigate(['/legal-tags'], { queryParams: { tags : legal.value } });
  }

  showFilterSearch(type){
    if(type=='query'){
      this.isShowSearch=!this.isShowSearch;
    }
    else{
      this.isShowSpatialFilter=!this.isShowSpatialFilter;
    }
   
  }

  populateStorageKind(val){
    this.isShowSearch=false;
   this.isDisabled=false;
   this.isShowSpatialFilter=false;
  }

  userOwnedSearch(event,val){
    console.log(event+","+val);
    this.isUserOwned=val;
    let timer = this.auth.refreshTokenTimer(this.auth.getIdToken());
    if(timer<=0){
      this.auth.subscribeRefreshToken();     
    }
    const data={
      "kind":this.selectedStorageKind,
      "queryAsOwner":val
    }  
    
   // this.getSearchDetails(data,'full')
     this.spinner.show()
   
    this.restService.SearchWells(data).subscribe((result) => {     
      this.spinner.hide();  
      let userOwnList=[];
      this.searchList.forEach(element => {
        let dataList=result["results"].filter(x=>x.id==element[".Id"]);
        if(dataList.length>0){
          userOwnList.push(dataList[0]);
        }
       
      });
      
      this.searchResultFunction(userOwnList,'user');    
   
    }, (err) => {
     this.spinner.hide();
     this.errorMessage=err;
     this.searchList=[];
     this.isDisabled=false;
      console.log(err);
    }); 
    // this.getSearchDetails(data,'full');

  }





  // requestSubmit(){
  //   this.isWellSearchAvailable=true;   

  //   let query="data.Data.IndividualTypeProperties.WellID:\"srn:master-data/Well:8690:\"";
   
  //   if(this.ngQuery!=''){
  //     query=this.ngQuery;
  //   }

  //   this.spinner.show();
  //   let timer = this.auth.refreshTokenTimer(this.auth.getIdToken());
  //   if(timer<=0){
  //     this.auth.subscribeRefreshToken();     
  //   }
  //   const data={
  //     "kind":this.selectedStorageKind
  //   }       
  //   this.getSearchDetails(data,'full');
  // }








}
